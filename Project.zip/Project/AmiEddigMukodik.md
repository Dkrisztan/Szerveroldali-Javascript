# Amik eddig működnek:

- [x] Új Ország hozzáadása
- [x] Ország törlése
- [ ] Ország módosítása
- [x] Látnivaló hozzáadása
- [x] Látnivaló törlése
- [ ] Látnivaló módosítása